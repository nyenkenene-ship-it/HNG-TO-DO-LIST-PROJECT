# TaskFlow Pro

A cloud-ready productivity app built around Supabase. It supports accounts, cloud tasks, projects, recurring tasks, reminders, search, calendar-style planning and productivity analytics.

## Setup
1. Create a Supabase project.
2. Open SQL Editor and run `schema.sql`.
3. Copy `config.example.js` to `config.js`.
4. Add your Supabase project URL and publishable/anon key to `config.js`.
5. Deploy the folder to Netlify or Vercel as a static site.

## Important
Only the browser-safe Supabase publishable/anon key belongs in `config.js`. Never put a Supabase service-role key in client-side code.

### Production reminders
- Configure your Supabase Auth email settings and redirect URL.
- Set your deployed site URL in Supabase Authentication URL Configuration.
- Email reminders require a server/Edge Function or automation; the UI stores reminder schedules in the database.
- Payments/subscriptions require a payment provider and server-side verification. This package includes a subscription-ready UI but does not process payments.
